available some information about schedule:
https://9292.nl/amstelveen/bushalte-poortwachter

https://9292.nl/amstelveen/bushalte-middenhoven-brink