from pprint import pprint
bus = {'bounds': {'northeast': {'lat': 52.34097, 'lng': 4.8740526},
            'southwest': {'lat': 52.283015, 'lng': 4.844657}},
 'copyrights': 'Map data ©2024',
 'legs': [{'arrival_time': {'text': '10:58\u202fPM',
                            'time_zone': 'Europe/Amsterdam',
                            'value': 1705701506},
           'departure_time': {'text': '10:13\u202fPM',
                              'time_zone': 'Europe/Amsterdam',
                              'value': 1705698802},
           'distance': {'text': '8.8 km', 'value': 8816},
           'duration': {'text': '45 mins', 'value': 2704},
           'end_address': 'Zuidas, Amsterdam, Netherlands',
           'end_location': {'lat': 52.33825299999999, 'lng': 4.8730553},
           'start_address': 'Poortwachter, 1188 CP Amstelveen, Netherlands',
           'start_location': {'lat': 52.2832854, 'lng': 4.8451277},
           'steps': [{'distance': {'text': '42 m', 'value': 42},
                      'duration': {'text': '1 min', 'value': 38},
                      'end_location': {'lat': 52.2832134,
                                       'lng': 4.844668899999999},
                      'html_instructions': 'Walk to Amstelveen, Poortwachter',
                      'polyline': {'points': 'qqb~Haiq\\ANAR?JVHC`@'},
                      'start_location': {'lat': 52.2832854, 'lng': 4.8451277},
                      'steps': [{'distance': {'text': '17 m', 'value': 17},
                                 'duration': {'text': '1 min', 'value': 17},
                                 'end_location': {'lat': 52.2833055,
                                                  'lng': 4.8448864},
                                 'html_instructions': 'Head <b>west</b><div '
                                                      'style="font-size:0.9em">Take '
                                                      'the stairs</div>',
                                 'polyline': {'points': 'qqb~Haiq\\ANAR?J'},
                                 'start_location': {'lat': 52.2832854,
                                                    'lng': 4.8451277},
                                 'travel_mode': 'WALKING'},
                                {'distance': {'text': '13 m', 'value': 13},
                                 'duration': {'text': '1 min', 'value': 11},
                                 'end_location': {'lat': 52.2831884,
                                                  'lng': 4.8448445},
                                 'html_instructions': 'Turn <b>left</b> toward '
                                                      '<b>De Uitvlugt</b>',
                                 'maneuver': 'turn-left',
                                 'polyline': {'points': 'uqb~Hqgq\\VH'},
                                 'start_location': {'lat': 52.2833055,
                                                    'lng': 4.8448864},
                                 'travel_mode': 'WALKING'},
                                {'distance': {'text': '12 m', 'value': 12},
                                 'duration': {'text': '1 min', 'value': 10},
                                 'end_location': {'lat': 52.2832134,
                                                  'lng': 4.844668899999999},
                                 'html_instructions': 'Turn <b>right</b> onto '
                                                      '<b>De Uitvlugt</b><div '
                                                      'style="font-size:0.9em">Destination '
                                                      'will be on the '
                                                      'left</div>',
                                 'maneuver': 'turn-right',
                                 'polyline': {'points': '}pb~Hggq\\C`@'},
                                 'start_location': {'lat': 52.2831884,
                                                    'lng': 4.8448445},
                                 'travel_mode': 'WALKING'}],
                      'travel_mode': 'WALKING'},
                     {'distance': {'text': '2.9 km', 'value': 2856},
                      'duration': {'text': '9 mins', 'value': 540},
                      'end_location': {'lat': 52.30224, 'lng': 4.85788},
                      'html_instructions': 'Bus towards Amstelveen Busstation',
                      'polyline': {'points': '{pb~Hcfq\\EABa@Dm@Dk@Fu@JaB@OMKOEMEQEKCEAG?G?m@O[GMW]gAGYMc@K]Dc@De@B_@Fw@BO`@_G@G@G@WHmA@G@YFw@?M@A@A@A?CBMB_@De@?C@U@MBOB[@WB_@@A@Q@[B]BY@S?C?A?CAC?AACAA?AAAA?AAAAA?ECYIKCSECAOEw@QqAYWISG?@A?A?A?KCUGGCECOGMEQGQEQEUGq@Ko@QQK[Ia@OKE_@K]KeAUkD{@SG_@Ik@Kq@Ii@GGAi@Ea@Ca@AaAA[A{@C]?AC?AAA?AAA?AA??AAAAAA?AAA?A?A?A?A?A??@A?A@A@?@A??@A@?@A@?@A@W?K?M?S@]?k@?MAKBIBQ?kAAKGA?KAMAC?[AYAQ@]CWC?ECGAECCCAAAEAA?C@C@CBCBABADABWBE?K@U@E@MFC?AAaACkBAIAo@A[Ao@AA?{@AuACgAA]AEEEAO?g@A]A]Ca@AKEOCQC]I]IaAWCA@DYBMGQ@UDWDC?aABA?QCg@UUMQIKEECIEeAo@gB_Ac@k@ECUUk@]KEQOYOYMWIUCOIKA?@m@SEU?W?MBi@MGMGPiA'},
                      'start_location': {'lat': 52.283182, 'lng': 4.844657},
                      'transit_details': {'arrival_stop': {'location': {'lat': 52.30224,
                                                                        'lng': 4.85788},
                                                           'name': 'Amstelveen, '
                                                                   'Busstation'},
                                          'arrival_time': {'text': '10:23\u202f'
                                                                   'PM',
                                                           'time_zone': 'Europe/Amsterdam',
                                                           'value': 1705699380},
                                          'departure_stop': {'location': {'lat': 52.283182,
                                                                          'lng': 4.844657},
                                                             'name': 'Amstelveen, '
                                                                     'Poortwachter'},
                                          'departure_time': {'text': '10:14\u202f'
                                                                     'PM',
                                                             'time_zone': 'Europe/Amsterdam',
                                                             'value': 1705698840},
                                          'headsign': 'Amstelveen Busstation',
                                          'line': {'agencies': [{'name': 'Connexxion',
                                                                 'phone': '011 '
                                                                          '31 '
                                                                          '900 '
                                                                          '2666399',
                                                                 'url': 'http://www.connexxion.nl/'}],
                                                   'color': '#d1ea32',
                                                   'name': 'Uithoorn '
                                                           'Busstation - '
                                                           'Amstelveen '
                                                           'Busstation',
                                                   'short_name': '348',
                                                   'text_color': '#000000',
                                                   'vehicle': {'icon': '//maps.gstatic.com/mapfiles/transit/iw2/6/bus2.png',
                                                               'name': 'Bus',
                                                               'type': 'BUS'}},
                                          'num_stops': 4},
                      'travel_mode': 'TRANSIT'},
                     {'distance': {'text': '72 m', 'value': 72},
                      'duration': {'text': '1 min', 'value': 59},
                      'end_location': {'lat': 52.3026892,
                                       'lng': 4.858234899999999},
                      'html_instructions': 'Walk to Amstelveen, Busstation',
                      'polyline': {'points': '_hf~Hsxs\\HDBUoAs@MIA?A?A?C@?@'},
                      'start_location': {'lat': 52.3022368, 'lng': 4.8578607},
                      'steps': [{'distance': {'text': '10 m', 'value': 10},
                                 'duration': {'text': '1 min', 'value': 8},
                                 'end_location': {'lat': 52.3021918,
                                                  'lng': 4.857831399999999},
                                 'html_instructions': 'Head <b>south</b>',
                                 'polyline': {'points': '_hf~Hsxs\\HD'},
                                 'start_location': {'lat': 52.3022368,
                                                    'lng': 4.8578607},
                                 'travel_mode': 'WALKING'},
                                {'distance': {'text': '62 m', 'value': 62},
                                 'duration': {'text': '1 min', 'value': 51},
                                 'end_location': {'lat': 52.3026892,
                                                  'lng': 4.858234899999999},
                                 'html_instructions': 'Cross the road<div '
                                                      'style="font-size:0.9em">Destination '
                                                      'will be on the '
                                                      'right</div>',
                                 'polyline': {'points': 'ugf~Hmxs\\BUoAs@MIA?A?A?C@?@'},
                                 'start_location': {'lat': 52.3021918,
                                                    'lng': 4.857831399999999},
                                 'travel_mode': 'WALKING'}],
                      'travel_mode': 'WALKING'},
                     {'distance': {'text': '5.5 km', 'value': 5454},
                      'duration': {'text': '15 mins', 'value': 900},
                      'end_location': {'lat': 52.34097, 'lng': 4.874032},
                      'html_instructions': 'Bus towards Station Zuid Amsterdam',
                      'polyline': {'points': '{jf~H}zs\\AFGCGCG?Mn@CVIXGVQLEICGE^EJCJKTI@m@NkA^IBuAV}AHqAJqAHw@AUGKIGAG?OHIFGHQDa@@qBEgDACEGAICQ?CBG@EHMC_@@iFIaG?i@AA??A]?W?cAA}AASAo@AaAAoACWAA?Y?U?YAe@AM?eCIIAY?a@@E?E?E?C?CAIEAAAAA?A??AA?A?A@A?A??@A??@A??@A??@SESEOEIAQCE?MAIAWCE?]EEAi@Ec@Ae@Cg@CQCw@?A?gAEaBIs@COAWCe@A_@AuAEe@CI?]Aa@?O?w@Eo@CcAEu@Ec@CM?O?S@M?U@C?CBC@I?EAG?G?}@Dw@?ECA?AAI?UCQAe@CMAQ?QAE?I?I?I@I?G@I@_@BI@C@IBeF@i@?E?wC@q@?W?E?U?_@@O?E?IAGAEAaAC[AYAS@I?I@I@G?G@M?K@G?Q?e@?W?s@?q@?k@?q@Ae@@e@?E?QC]Bw@?Q?w@?i@?Y@uA@i@Aa@AE?C?EAC?E?CAGAE?IAKAA?MAM@IBS@E@Q?W@OAKAG?EAI@M?I@I?UBS@Q@OAM?U@m@AICOCsAUy@G@I@M?I?Y?M?S?{B@iD?a@?W?w@@_@?S?u@?Q@cC?{@?W?A?QAW?mN?aBTyC?S?m@?y@?{@Ak@AW?K?O?E?M?e@?G?Y?uA?oB?]?K?UQ?c@C}@?e@?e@?uB@[AW?]@W@oANWBQBE?A?gABY@mCJU@K@{@DY@a@B_ABm@Dc@BUBIa@AEAK?Q?S?[?a@CqBAi@?U?a@Ak@EkCCsACSGqE@MAW@IA[?O?E?EC{@?g@AYg@B'},
                      'start_location': {'lat': 52.30269999999999,
                                         'lng': 4.85823},
                      'transit_details': {'arrival_stop': {'location': {'lat': 52.34097,
                                                                        'lng': 4.874032},
                                                           'name': 'Amsterdam, '
                                                                   'Station '
                                                                   'Zuid'},
                                          'arrival_time': {'text': '10:53\u202f'
                                                                   'PM',
                                                           'time_zone': 'Europe/Amsterdam',
                                                           'value': 1705701180},
                                          'departure_stop': {'location': {'lat': 52.30269999999999,
                                                                          'lng': 4.85823},
                                                             'name': 'Amstelveen, '
                                                                     'Busstation'},
                                          'departure_time': {'text': '10:38\u202f'
                                                                     'PM',
                                                             'time_zone': 'Europe/Amsterdam',
                                                             'value': 1705700280},
                                          'headsign': 'Station Zuid Amsterdam',
                                          'line': {'agencies': [{'name': 'Connexxion',
                                                                 'phone': '011 '
                                                                          '31 '
                                                                          '900 '
                                                                          '2666399',
                                                                 'url': 'http://www.connexxion.nl/'}],
                                                   'color': '#d1ea32',
                                                   'name': 'Kudelstaart/Aalsmeer '
                                                           '- Amsterdam '
                                                           'Station Zuid',
                                                   'short_name': '358',
                                                   'text_color': '#000000',
                                                   'url': 'http://www.connexxion.nl/dienstregeling/lijn?ID=M358',
                                                   'vehicle': {'icon': '//maps.gstatic.com/mapfiles/transit/iw2/6/bus2.png',
                                                               'name': 'Bus',
                                                               'type': 'BUS'}},
                                          'num_stops': 7},
                      'travel_mode': 'TRANSIT'},
                     {'distance': {'text': '0.4 km', 'value': 392},
                      'duration': {'text': '5 mins', 'value': 326},
                      'end_location': {'lat': 52.33825299999999,
                                       'lng': 4.8730553},
                      'html_instructions': 'Walk to Zuidas, Amsterdam, '
                                           'Netherlands',
                      'polyline': {'points': '_zm~Hu}v\\@z@?F@N?NBV@v@@?F??@RCLAJAJAJAL?LALAH?N@LAb@C\\CNA?GZBb@Gb@Ib@IHCVCb@Eb@Eb@E?n@Af@?B@@?@@@B?BA'},
                      'start_location': {'lat': 52.3409583, 'lng': 4.8740306},
                      'steps': [{'distance': {'text': '62 m', 'value': 62},
                                 'duration': {'text': '1 min', 'value': 52},
                                 'end_location': {'lat': 52.3408959,
                                                  'lng': 4.8731265},
                                 'html_instructions': 'Head <b>west</b> on '
                                                      '<b>Strawinskylaan</b>',
                                 'polyline': {'points': '_zm~Hu}v\\@z@?F@N?NBV@v@@?'},
                                 'start_location': {'lat': 52.3409583,
                                                    'lng': 4.8740306},
                                 'travel_mode': 'WALKING'},
                                {'distance': {'text': '0.1 km', 'value': 133},
                                 'duration': {'text': '2 mins', 'value': 112},
                                 'end_location': {'lat': 52.3396896,
                                                  'lng': 4.8732469},
                                 'html_instructions': 'Take the crosswalk<div '
                                                      'style="font-size:0.9em">Take '
                                                      'the stairs</div>',
                                 'polyline': {'points': 'sym~Haxv\\F??@RCLAJAJAJAL?LALAH?N@LAb@C\\CNA'},
                                 'start_location': {'lat': 52.3408959,
                                                    'lng': 4.8731265},
                                 'travel_mode': 'WALKING'},
                                {'distance': {'text': '3 m', 'value': 3},
                                 'duration': {'text': '1 min', 'value': 2},
                                 'end_location': {'lat': 52.3396912,
                                                  'lng': 4.873289300000001},
                                 'html_instructions': 'Turn <b>left</b> onto '
                                                      '<b>Zuidplein</b>',
                                 'maneuver': 'turn-left',
                                 'polyline': {'points': 'arm~Hyxv\\?G'},
                                 'start_location': {'lat': 52.3396896,
                                                    'lng': 4.8732469},
                                 'travel_mode': 'WALKING'},
                                {'distance': {'text': '16 m', 'value': 16},
                                 'duration': {'text': '1 min', 'value': 11},
                                 'end_location': {'lat': 52.3395501,
                                                  'lng': 4.8732653},
                                 'html_instructions': 'Turn <b>right</b>',
                                 'maneuver': 'turn-right',
                                 'polyline': {'points': 'arm~Hayv\\ZB'},
                                 'start_location': {'lat': 52.3396912,
                                                    'lng': 4.873289300000001},
                                 'travel_mode': 'WALKING'},
                                {'distance': {'text': '0.1 km', 'value': 140},
                                 'duration': {'text': '2 mins', 'value': 117},
                                 'end_location': {'lat': 52.3383,
                                                  'lng': 4.873545},
                                 'html_instructions': 'Slight <b>left</b>',
                                 'maneuver': 'turn-slight-left',
                                 'polyline': {'points': 'eqm~H}xv\\b@Gb@Ib@IHCVCb@Eb@Eb@E'},
                                 'start_location': {'lat': 52.3395501,
                                                    'lng': 4.8732653},
                                 'travel_mode': 'WALKING'},
                                {'distance': {'text': '38 m', 'value': 38},
                                 'duration': {'text': '1 min', 'value': 32},
                                 'end_location': {'lat': 52.33825299999999,
                                                  'lng': 4.8730553},
                                 'html_instructions': 'Turn <b>right</b><div '
                                                      'style="font-size:0.9em">Destination '
                                                      'will be on the '
                                                      'right</div>',
                                 'maneuver': 'turn-right',
                                 'polyline': {'points': 'kim~Hszv\\?n@Af@?B@@?@@@B?BA'},
                                 'start_location': {'lat': 52.3383,
                                                    'lng': 4.873545},
                                 'travel_mode': 'WALKING'}],
                      'travel_mode': 'WALKING'}],
           'traffic_speed_entry': [],
           'via_waypoint': []}],
 'overview_polyline': {'points': 'qqb~Haiq\\Cb@?JVHC`@D@EABa@JyARwC@OMK]K]IMAu@O[GMWe@aBYaAVaDh@_HNgCFeABCHs@VqDNaCCMEEiA]qD{@SEC?k@Ou@Yc@KgASo@QQK}@Yk@QcBa@_EcAkAUmCYaDIyACAEACGIGAI@GHABe@BkB@u@DkAAKGMAgAEo@AWC?EEMGEMAMLCH]Ba@BSHsDGeCG{EG]AEEUAeCIkAW_Ba@CA@DYBMGg@F[DcABQCg@Ug@WaB_AgB_Ac@k@[Yw@c@k@_@q@WUCOIK?m@SEU?e@Bi@MGMGPiAHHBUoAs@OIGBCFOGG?Mn@Mp@GVQLIQKj@O`@w@PuAb@uAV}AHcDTw@AUGSKWHQPQDa@@yGGKG[CKDEHMCiGGkHAw@AqKOgHOs@@SIEAKBC@w@OuBSyBMy@Gy@?mFUsDMoBE{DOwBI{@BGDOAO?uBDSE{AKs@Ae@Bs@FMDoG@gF@kA@]EkCEoAFyH?gG?oBBkACSA}@IWDYBi@@[Ce@?}@FeA@m@AICcBYy@G@I@W?wDBwK?sYTmD?gBCkC?qH?i@?UQ?aBCkA?gE@qCXyGTwDNqAHUBIa@CQ?e@EyEGoFGgBE_FAmACoBAYg@BBz@D~@@v@@?F@x@It@EX@p@El@E?GZBfAQl@MbCU?|AH@'},
 'summary': '',
 'warnings': ['Walking directions are in beta. Use caution – This route may be '
              'missing sidewalks or pedestrian paths.'],
 'waypoint_order': []}


def serialize_bus():
    # Extract relevant information
    transit_details = bus.get('legs', 'Key not found')
    keys = bus.keys()
    pprint(keys)
    pprint(transit_details)
    departure_time = transit_details[0].get('departure_time', 'N/A').get('text', 'N/A')
    print('-------')
    pprint(departure_time)
    pprint(transit_details[0])
    print(type(transit_details[0]))

    transit_details_dict = transit_details[0]

    # departure_stop = tram_result['legs'][0]['steps'][0]['transit_details']['departure_stop']['name']
    # arrival_stop = tram_result['legs'][0]['steps'][0]['transit_details']['arrival_stop']['name']
    # vehicle_number = tram_result['legs'][0]['steps'][0]['transit_details']['line']['short_name']
    # transp_type = tram_result['legs'][0]['steps'][0]['transit_details']['line']['vehicle']['type']
    # arrival_time = tram_result['legs'][0]['steps'][0]['transit_details']['arrival_time']['text']
    # departure_time = tram_result['legs'][0]['steps'][0]['transit_details']['departure_time']['text']

    departure_stop = transit_details_dict.get('departure_stop', 'N/A')
    pprint(departure_stop)
    arrival_stop = transit_details_dict.get('arrival_stop', 'N/A').get('name', 'N/A')
    vehicle_number = transit_details_dict.get('steps', 'N/A').get('line', 'N/A').get('short_name', 'N/A')
    transp_type = transit_details_dict.get('line', {}).get('vehicle', 'N/A').get('type', 'N/A')

    arrival_time = transit_details_dict.get('arrival_time', {}).get('text', 'N/A')

    result_dict = {'departure_stop': departure_stop,
                        'arrival_stop': arrival_stop,
                        'tram_number': vehicle_number,
                        'transp_type': transp_type,
                        'arrival_time': arrival_time,
                        'departure_time': departure_time
                        }
    pprint(result_dict)

serialize_bus()